(function () {
  // ---------------------------------------------------------------------------
  // 0. Auto-Update Engine Config (GitHub Releases Integration)
  // ---------------------------------------------------------------------------
  const CURRENT_VERSION = "3.0"; 

  const GITHUB_USER = "safwanmohmd";
  const GITHUB_REPO = "kot-scandeck";

  const VERSION_CHECK_URL = `https://raw.githubusercontent.com/${GITHUB_USER}/${GITHUB_REPO}/main/version.json`;

  async function checkForUpdates() {
    try {
      const response = await fetch(`${VERSION_CHECK_URL}?t=${Date.now()}`);
      if (!response.ok) return;

      const data = await response.json();
      if (data.latestVersion && data.latestVersion !== CURRENT_VERSION) {
        showUpdateBanner(data.latestVersion, data.downloadUrl);
      }
    } catch (e) {
      console.log("GitHub release version check skipped:", e);
    }
  }

  function showUpdateBanner(newVersion, downloadUrl) {
    const banner = shadowRoot.getElementById('update-banner');
    const textEl = shadowRoot.getElementById('update-banner-text');
    const btn = shadowRoot.getElementById('update-download-btn');

    if (banner && textEl && btn) {
      textEl.textContent = `🚀 New Update Available (v${newVersion})!`;
      banner.style.display = 'flex';
      btn.onclick = () => {
        window.open(downloadUrl, '_blank');
      };
    }
  }

  // Saved Settings for Alarms
  let enableRtoAlarm = localStorage.getItem('barcode_enable_rto_alarm') === 'true';
  let enableCpdAlarm = localStorage.getItem('barcode_enable_cpd_alarm') === 'true';

  // ---------------------------------------------------------------------------
  // 1. Custom Audio File Player & Mutual Exclusion Detection Engines
  // ---------------------------------------------------------------------------
  let currentAudioInstance = null;
  let currentCpdAudioInstance = null;

  function playRTOAlarmSound() {
    try {
      if (currentAudioInstance) {
        currentAudioInstance.pause();
        currentAudioInstance.currentTime = 0;
      }

      const soundUrl = chrome.runtime.getURL('alarm.mp3');
      currentAudioInstance = new Audio(soundUrl);
      currentAudioInstance.volume = 1.0;

      const playPromise = currentAudioInstance.play();
      if (playPromise !== undefined) {
        playPromise.catch(error => {
          console.warn("RTO audio playback blocked. Click anywhere on the page once to enable audio.", error);
        });
      }
    } catch (e) {
      console.error("Custom RTO Sound Alert failed:", e);
    }
  }

  function playCPDAlarmSound() {
    try {
      if (currentCpdAudioInstance) {
        currentCpdAudioInstance.pause();
        currentCpdAudioInstance.currentTime = 0;
      }

      const soundUrl = chrome.runtime.getURL('cpd_alarm.mp3');
      currentCpdAudioInstance = new Audio(soundUrl);
      currentCpdAudioInstance.volume = 1.0; // 100% Volume

      const playPromise = currentCpdAudioInstance.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          playFallbackBeep();
        });
      }
    } catch (e) {
      playFallbackBeep();
    }
  }

  function playFallbackBeep() {
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      osc.frequency.setValueAtTime(440, audioCtx.currentTime + 0.15);
      gain.gain.setValueAtTime(1.0, audioCtx.currentTime); // 100% Volume
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.35);
    } catch (err) {
      console.warn("Fallback beep failed:", err);
    }
  }

  function getTodayDateString() {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  let lastAlarmTimestamp = 0;

  function inspectPageForAlerts() {
    const isPanelActive = panel && !panel.classList.contains('panel-hidden');
    if (!isPanelActive) return;

    const elements = Array.from(document.querySelectorAll('.sc-AykKC, .fmcvyS, div, td, tr, span'));

    // Step A: Detect IS RTO state
    let isRtoYesDetected = false;
    const rtoLabelNode = elements.find(el => {
      const text = el.textContent ? el.textContent.trim().toUpperCase() : '';
      return text === "IS RTO" || text === "IS RTO:";
    });

    if (rtoLabelNode) {
      const parentCell = rtoLabelNode.closest('.fmcvyS, div, td') || rtoLabelNode.parentElement;
      const containerText = parentCell ? parentCell.textContent.toUpperCase() : '';

      if (containerText.includes('YES') && !containerText.includes('IS RTO CV')) {
        isRtoYesDetected = true;
      }
    } else {
      const bodyText = (document.body.textContent || document.body.innerText || '')
        .replace(/\s+/g, ' ')
        .toUpperCase();
      
      if (bodyText.includes('IS RTO YES')) {
        isRtoYesDetected = true;
      }
    }

    // Step B: Detect CPD Today state
    let isTodayCpdDetected = false;
    const todayStr = getTodayDateString();
    const cpdLabelNode = elements.find(el => {
      const text = el.textContent ? el.textContent.trim().toUpperCase() : '';
      return text === "CPD" || text === "CPD:";
    });

    if (cpdLabelNode) {
      const parentCell = cpdLabelNode.closest('.fmcvyS, div, td') || cpdLabelNode.parentElement;
      const containerText = parentCell ? parentCell.textContent : '';

      if (containerText.includes(todayStr)) {
        isTodayCpdDetected = true;
      }
    }

    // Step C: Strict Priority / Mutually Exclusive Alarm Triggering
    const now = Date.now();
    if (now - lastAlarmTimestamp > 500) {
      if (isRtoYesDetected && enableRtoAlarm) {
        playRTOAlarmSound();
        lastAlarmTimestamp = now;
      } else if (!isRtoYesDetected && isTodayCpdDetected && enableCpdAlarm) {
        playCPDAlarmSound();
        lastAlarmTimestamp = now;
      }
    }
  }

  const alertObserver = new MutationObserver(() => {
    inspectPageForAlerts();
  });

  alertObserver.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });

  // ---------------------------------------------------------------------------
  // 2. Extension Handshake Bridge
  // ---------------------------------------------------------------------------
  window.addEventListener('CHECK_BARCODE_EXTENSION', () => {
    window.dispatchEvent(new CustomEvent('BARCODE_EXTENSION_INSTALLED', {
      detail: { version: CURRENT_VERSION, installed: true }
    }));
  });

  window.addEventListener('LOAD_TRACKING_IDS_TO_EXTENSION', (event) => {
    if (event.detail && event.detail.trackingIds) {
      const barcodeInput = shadowRoot.getElementById('barcode-input');
      if (barcodeInput) {
        barcodeInput.value = event.detail.trackingIds;
        processAndFilterQueue();
        panel.classList.remove('panel-hidden');
        panelBody.classList.remove('minimized');
      }
    }
  });

  if (document.getElementById('barcode-injector-root')) return;

  // ---------------------------------------------------------------------------
  // 3. Constants & State Variables
  // ---------------------------------------------------------------------------
  const TRACKING_ID_EXTRACT_REGEX = /^[A-Z]{3,4}[A-Z0-9\-_]{5,15}$/i;

  let isRunning = false;
  let isPaused = false;
  let shouldStop = false;
  let trackingQueue = [];
  let currentIndex = 0;

  // Saved Settings
  let toggleHotkey = localStorage.getItem('barcode_toggle_hotkey') || 'Alt + S';
  let startHotkey = localStorage.getItem('barcode_start_hotkey') || 'Alt + X';
  let scanDelay = parseInt(localStorage.getItem('barcode_scan_delay') || '100', 10);
  let isolateTracking = localStorage.getItem('barcode_isolate_tracking') !== 'false';
  let enableExclusions = localStorage.getItem('barcode_enable_exclusions') !== 'false';
  let excludeWords = localStorage.getItem('barcode_exclude_words') || 'FORWARD, UNDELIVERED, FLIPKART, ESCALATION, VERIFICATION, SHIPMENTS, PACKAGING, MANDATORY';

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {
      if (message.action === 'TOGGLE_PANEL') {
        panel.classList.toggle('panel-hidden');
      }
    });
  }

  // ---------------------------------------------------------------------------
  // 4. Shadow DOM Container Setup & Modern Smooth CSS
  // ---------------------------------------------------------------------------
  const rootContainer = document.createElement('div');
  rootContainer.id = 'barcode-injector-root';
  document.body.appendChild(rootContainer);

  const shadowRoot = rootContainer.attachShadow({ mode: 'open' });

  const style = document.createElement('style');
  style.textContent = `
    * { 
      box-sizing: border-box; 
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; 
      -webkit-font-smoothing: antialiased;
    }
    
    #panel {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 340px;
      min-width: 280px;
      max-width: 550px;
      min-height: 200px;
      background: #ffffff;
      border: 1px solid rgba(226, 232, 240, 0.9);
      border-radius: 14px;
      box-shadow: 0 16px 36px -4px rgba(15, 23, 42, 0.16), 0 4px 12px -2px rgba(15, 23, 42, 0.08);
      z-index: 999999;
      overflow: hidden;
      resize: both;
      display: flex;
      flex-direction: column;
      backdrop-filter: blur(10px);
      transition: opacity 0.2s cubic-bezier(0.4, 0, 0.2, 1), transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    #panel.panel-hidden { 
      display: none !important; 
    }

    .header {
      background: #0f172a;
      color: #ffffff;
      padding: 10px 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: move;
      user-select: none;
      flex-shrink: 0;
      border-bottom: 1px solid #1e293b;
    }
    .header-title { 
      font-weight: 700; 
      font-size: 11.5px; 
      letter-spacing: 0.3px; 
      display: flex; 
      align-items: center; 
      gap: 6px; 
      color: #f8fafc;
    }
    .header-btns { display: flex; gap: 6px; align-items: center; }
    .header-btns button {
      background: rgba(255, 255, 255, 0.08); 
      border: none; 
      color: #94a3b8; 
      width: 20px; 
      height: 20px; 
      border-radius: 5px; 
      font-size: 11px; 
      cursor: pointer; 
      display: flex; 
      align-items: center; 
      justify-content: center;
      transition: all 0.15s ease;
    }
    .header-btns button:hover { 
      background: rgba(255, 255, 255, 0.2); 
      color: #ffffff; 
    }

    .body { 
      padding: 12px; 
      display: flex; 
      flex-direction: column; 
      gap: 10px; 
      overflow-y: auto; 
      flex-grow: 1; 
      background: #ffffff;
      position: relative;
    }
    .body.minimized { display: none; }
    
    .update-banner {
      background: #fffbeb;
      border: 1px solid #fde68a;
      color: #92400e;
      padding: 6px 10px;
      border-radius: 8px;
      display: none;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 700;
    }
    .btn-update-dl {
      background: #f59e0b;
      color: white;
      border: none;
      padding: 3px 8px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 10px;
      font-weight: 600;
      transition: background 0.15s;
    }
    .btn-update-dl:hover { background: #d97706; }

    label { 
      font-size: 10px; 
      font-weight: 700; 
      color: #64748b; 
      text-transform: uppercase; 
      letter-spacing: 0.4px; 
    }
    
    textarea {
      width: 100%; 
      height: 55px; 
      padding: 8px; 
      border: 1px solid #cbd5e1; 
      border-radius: 8px;
      font-size: 11px; 
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; 
      resize: vertical; 
      outline: none;
      background: #f8fafc;
      transition: border-color 0.2s, box-shadow 0.2s;
    }
    textarea:focus {
      border-color: #2563eb;
      box-shadow: 0 0 0 2.5px rgba(37, 99, 235, 0.15);
      background: #ffffff;
    }

    .btn-group { display: flex; gap: 6px; }
    button.btn {
      flex: 1; 
      padding: 7px; 
      border: none; 
      border-radius: 7px; 
      font-weight: 600; 
      font-size: 11px;
      cursor: pointer; 
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); 
      display: flex; 
      align-items: center; 
      justify-content: center; 
      gap: 5px;
    }
    .btn:active { transform: scale(0.98); }
    .btn-primary { background: #2563eb; color: white; box-shadow: 0 2px 6px rgba(37, 99, 235, 0.25); }
    .btn-primary:hover { background: #1d4ed8; }
    .btn-warning { background: #f59e0b; color: white; }
    .btn-warning:hover { background: #d97706; }
    .btn-danger { background: #ef4444; color: white; }
    .btn-danger:hover { background: #dc2626; }
    .btn-reset { 
      background: #fee2e2; 
      color: #b91c1c; 
      border: 1px solid #fca5a5; 
      width: 100%; 
      font-weight: 700; 
      padding: 7px; 
    }
    .btn-reset:hover { background: #fecaca; }
    .btn-secondary { background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; }
    .btn-secondary:hover { background: #e2e8f0; }
    button:disabled { opacity: 0.45; cursor: not-allowed; transform: none !important; }

    .progress-box { 
      background: #f8fafc; 
      border: 1px solid #e2e8f0; 
      border-radius: 8px; 
      padding: 8px 10px; 
    }
    .progress-bar-bg { 
      background: #e2e8f0; 
      height: 6px; 
      border-radius: 4px; 
      overflow: hidden; 
      margin-top: 5px; 
    }
    .progress-bar-fill { 
      background: linear-gradient(90deg, #2563eb, #3b82f6); 
      height: 100%; 
      width: 0%; 
      border-radius: 4px;
      transition: width 0.25s ease-out; 
    }
    .status-text { 
      font-size: 10px; 
      color: #64748b; 
      font-weight: 600; 
      display: flex; 
      justify-content: space-between; 
    }

    /* Modern Card Sections */
    .filter-section {
      background: #f8fafc; 
      border: 1px solid #e2e8f0; 
      border-radius: 10px; 
      padding: 9px;
      display: flex; 
      flex-direction: column; 
      gap: 7px;
    }
    
    .setting-row { 
      display: flex; 
      justify-content: space-between; 
      align-items: center; 
    }
    .setting-input {
      background: #ffffff; 
      border: 1px solid #cbd5e1; 
      border-radius: 6px; 
      padding: 3px 6px;
      font-size: 10px; 
      font-weight: 700; 
      color: #2563eb; 
      width: 95px; 
      text-align: center; 
      cursor: pointer;
      outline: none;
      transition: border-color 0.15s;
    }
    .setting-input:focus { border-color: #2563eb; }

    /* Modern Smooth Switch Component */
    .switch-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 3px 0;
      user-select: none;
    }
    .switch-title {
      font-size: 10.5px;
      font-weight: 600;
      color: #334155;
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .smooth-switch {
      position: relative;
      display: inline-block;
      width: 32px;
      height: 18px;
      flex-shrink: 0;
    }
    .smooth-switch input {
      opacity: 0;
      width: 0;
      height: 0;
      margin: 0;
      position: absolute;
    }
    .switch-slider {
      position: absolute;
      cursor: pointer;
      top: 0; left: 0; right: 0; bottom: 0;
      background-color: #cbd5e1;
      transition: background-color 0.25s cubic-bezier(0.4, 0, 0.2, 1);
      border-radius: 20px;
    }
    .switch-slider::before {
      position: absolute;
      content: "";
      height: 14px;
      width: 14px;
      left: 2px;
      bottom: 2px;
      background-color: #ffffff;
      transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1), width 0.15s ease;
      border-radius: 50%;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    }
    .smooth-switch input:checked + .switch-slider {
      background-color: #2563eb;
    }
    .smooth-switch input:checked + .switch-slider::before {
      transform: translateX(14px);
    }
    .smooth-switch input:active + .switch-slider::before {
      width: 16px;
    }

    /* Emerald Theme for CPD Switch & Container */
    .cpd-card {
      background: #f0fdf4;
      border: 1px solid #bbf7d0;
      border-radius: 8px;
      padding: 6px 8px;
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    .cpd-card .switch-title {
      color: #15803d;
      font-weight: 700;
    }
    .cpd-switch input:checked + .switch-slider {
      background-color: #059669 !important;
    }
    .btn-cpd-action {
      background: #ffffff;
      color: #047857;
      border: 1px solid #a7f3d0;
      font-weight: 600;
      box-shadow: 0 1px 2px rgba(5, 150, 105, 0.08);
    }
    .btn-cpd-action:hover {
      background: #ecfdf5;
      border-color: #6ee7b7;
    }

    /* Exclusion Settings Gear Button */
    .btn-gear-settings {
      background: none;
      border: 1px solid #cbd5e1;
      border-radius: 4px;
      color: #64748b;
      cursor: pointer;
      padding: 1px 5px;
      font-size: 10px;
      line-height: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
    }
    .btn-gear-settings:hover {
      background: #e2e8f0;
      color: #0f172a;
    }

    /* Exclusion Words Modal */
    .modal-overlay {
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(15, 23, 42, 0.5);
      backdrop-filter: blur(2px);
      z-index: 1000;
      display: none;
      align-items: center;
      justify-content: center;
      padding: 14px;
    }
    .modal-overlay.open {
      display: flex;
    }
    .modal-card {
      background: #ffffff;
      border-radius: 10px;
      border: 1px solid #e2e8f0;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
      width: 100%;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .modal-title {
      font-size: 11px;
      font-weight: 700;
      color: #1e293b;
    }
    .modal-close-btn {
      background: none;
      border: none;
      color: #94a3b8;
      font-size: 12px;
      cursor: pointer;
      padding: 0 4px;
    }
    .modal-close-btn:hover {
      color: #0f172a;
    }

    .settings-grid {
      background: #f8fafc; 
      border: 1px solid #e2e8f0; 
      border-radius: 10px; 
      padding: 8px;
      display: flex; 
      flex-direction: column; 
      gap: 6px;
    }
  `;

  const panel = document.createElement('div');
  panel.id = 'panel';
  panel.className = 'panel-hidden';
  panel.innerHTML = `
    <div class="header" id="drag-handle">
      <span class="header-title">⚡ KOT-ScanDeck v${CURRENT_VERSION}</span>
      <div class="header-btns">
        <button id="minimize-btn" title="Minimize">—</button>
        <button id="close-btn" title="Close Panel">✕</button>
      </div>
    </div>
    <div class="body" id="panel-body">
      <div id="update-banner" class="update-banner">
        <span id="update-banner-text">🚀 New Update Available!</span>
        <button id="update-download-btn" class="btn-update-dl">📥 Get Update</button>
      </div>

      <div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
          <label>Raw Data Input</label>
          <div style="display:flex; gap:4px;">
            <button id="copy-btn" class="btn btn-secondary" style="padding:2px 7px; font-size:9.5px; border-radius:4px;" title="Copy filtered tracking IDs">📄 Copy</button>
            <button id="paste-btn" class="btn btn-secondary" style="padding:2px 7px; font-size:9.5px; border-radius:4px;">📋 Paste</button>
          </div>
        </div>
        <textarea id="barcode-input" placeholder="Paste manifest / logs here..."></textarea>
      </div>

      <div class="filter-section">
        <!-- RTO Alarm Switch -->
        <div class="switch-row">
          <span class="switch-title">🔊 Enable RTO Custom Alarm</span>
          <label class="smooth-switch">
            <input type="checkbox" id="enable-rto-alarm-chk" ${enableRtoAlarm ? 'checked' : ''} />
            <span class="switch-slider"></span>
          </label>
        </div>

        <div class="setting-row">
          <label style="text-transform:none; font-size:10px;">RTO Audio Test:</label>
          <button id="test-sound-btn" class="btn btn-secondary" style="padding: 2px 7px; font-size:9.5px; border-radius:4px;" title="Test Audio">🔊 Test MP3</button>
        </div>

        <!-- CPD Alarm Emerald Toggle Card -->
        <div class="cpd-card">
          <div class="switch-row">
            <span class="switch-title">📅 Enable Today CPD Alarm</span>
            <label class="smooth-switch cpd-switch">
              <input type="checkbox" id="enable-cpd-alarm-chk" ${enableCpdAlarm ? 'checked' : ''} />
              <span class="switch-slider"></span>
            </label>
          </div>

          <div class="setting-row">
            <label style="text-transform:none; font-size:10px; color: #15803d;">CPD Audio Test:</label>
            <button id="test-cpd-sound-btn" class="btn btn-cpd-action" style="padding: 2px 7px; font-size:9.5px; border-radius:4px;" title="Test CPD Audio">🎵 Test CPD</button>
          </div>
        </div>

        <!-- Tracking Isolator Switch -->
        <div class="switch-row" style="margin-top: 3px;">
          <span class="switch-title">Isolate Tracking Format</span>
          <label class="smooth-switch">
            <input type="checkbox" id="isolate-tracking-chk" ${isolateTracking ? 'checked' : ''} />
            <span class="switch-slider"></span>
          </label>
        </div>

        <!-- Keywords Exclusion Switch & Settings Button -->
        <div class="switch-row">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span class="switch-title">Exclusion Keywords Block</span>
            <button id="open-exclusions-btn" class="btn-gear-settings" title="Edit exclusion keywords">⚙️ Settings</button>
          </div>
          <label class="smooth-switch">
            <input type="checkbox" id="enable-exclusions-chk" ${enableExclusions ? 'checked' : ''} />
            <span class="switch-slider"></span>
          </label>
        </div>
      </div>

      <!-- Exclusion Keywords Modal -->
      <div id="exclusions-modal" class="modal-overlay">
        <div class="modal-card">
          <div class="modal-header">
            <span class="modal-title">⚙️ Exclusion Keywords</span>
            <button id="close-modal-btn" class="modal-close-btn" title="Close">✕</button>
          </div>
          <label style="font-size: 9.5px; text-transform: none; color: #64748b;">Separate keywords using commas, semicolons, or lines:</label>
          <textarea id="exclude-words-input" style="height: 70px; font-size:10px;" placeholder="Exclusion keywords...">${excludeWords}</textarea>
          <button id="save-modal-btn" class="btn btn-primary" style="padding: 5px; font-size: 10px;">Done</button>
        </div>
      </div>

      <div class="settings-grid">
        <div class="setting-row">
          <label>Hide/Show Shortcut:</label>
          <input type="text" id="toggle-hotkey-input" class="setting-input" value="${toggleHotkey}" readonly />
        </div>
        <div class="setting-row">
          <label>Start Scan Shortcut:</label>
          <input type="text" id="start-hotkey-input" class="setting-input" value="${startHotkey}" readonly />
        </div>
        <div class="setting-row">
          <label>Interval Delay (ms):</label>
          <input type="number" id="delay-input" class="setting-input" style="cursor:text;" value="${scanDelay}" step="10" min="0" />
        </div>
      </div>

      <div class="btn-group">
        <button id="start-btn" class="btn btn-primary">▶ Start</button>
        <button id="pause-btn" class="btn btn-warning" disabled>⏸ Pause</button>
        <button id="stop-btn" class="btn btn-danger" disabled>⏹ Stop</button>
      </div>

      <button id="reset-kill-btn" class="btn btn-reset">🚨 Reset</button>

      <div class="progress-box">
        <div class="status-text">
          <span id="status-label">Status: Idle</span>
          <span id="counter-label">0/0</span>
        </div>
        <div class="progress-bar-bg">
          <div id="progress-fill" class="progress-bar-fill"></div>
        </div>
      </div>
    </div>
  `;

  shadowRoot.appendChild(style);
  shadowRoot.appendChild(panel);

  const barcodeInput = shadowRoot.getElementById('barcode-input');
  const enableRtoAlarmChk = shadowRoot.getElementById('enable-rto-alarm-chk');
  const enableCpdAlarmChk = shadowRoot.getElementById('enable-cpd-alarm-chk');
  const testSoundBtn = shadowRoot.getElementById('test-sound-btn');
  const testCpdSoundBtn = shadowRoot.getElementById('test-cpd-sound-btn');
  const isolateChk = shadowRoot.getElementById('isolate-tracking-chk');
  const enableExclusionChk = shadowRoot.getElementById('enable-exclusions-chk');
  const excludeWordsInput = shadowRoot.getElementById('exclude-words-input');

  const exclusionsModal = shadowRoot.getElementById('exclusions-modal');
  const openExclusionsBtn = shadowRoot.getElementById('open-exclusions-btn');
  const closeModalBtn = shadowRoot.getElementById('close-modal-btn');
  const saveModalBtn = shadowRoot.getElementById('save-modal-btn');

  const startBtn = shadowRoot.getElementById('start-btn');
  const pauseBtn = shadowRoot.getElementById('pause-btn');
  const stopBtn = shadowRoot.getElementById('stop-btn');
  const resetKillBtn = shadowRoot.getElementById('reset-kill-btn');
  const copyBtn = shadowRoot.getElementById('copy-btn');
  const pasteBtn = shadowRoot.getElementById('paste-btn');
  const minimizeBtn = shadowRoot.getElementById('minimize-btn');
  const closeBtn = shadowRoot.getElementById('close-btn');
  const panelBody = shadowRoot.getElementById('panel-body');
  const statusLabel = shadowRoot.getElementById('status-label');
  const counterLabel = shadowRoot.getElementById('counter-label');
  const progressFill = shadowRoot.getElementById('progress-fill');
  const dragHandle = shadowRoot.getElementById('drag-handle');
  
  const toggleHotkeyInput = shadowRoot.getElementById('toggle-hotkey-input');
  const startHotkeyInput = shadowRoot.getElementById('start-hotkey-input');
  const delayInput = shadowRoot.getElementById('delay-input');

  setTimeout(checkForUpdates, 2000);

  // ---------------------------------------------------------------------------
  // 5. Filtering Engine
  // ---------------------------------------------------------------------------
  function processAndFilterQueue() {
    const rawText = barcodeInput.value || '';
    const lines = rawText.split(/\s+/).map(s => s.trim()).filter(Boolean);

    const blockedKeywords = excludeWordsInput.value
      .split(/[\n,;\t]+/)
      .map(w => w.trim().toUpperCase())
      .filter(Boolean);

    const filtered = [];
    const seen = new Set();

    for (let segment of lines) {
      let targetValue = segment;
      const upperSegment = segment.toUpperCase();

      if (enableExclusionChk.checked) {
        if (blockedKeywords.some(keyword => upperSegment === keyword || upperSegment.includes(keyword))) {
          continue;
        }
      }

      if (isolateChk.checked) {
        if (TRACKING_ID_EXTRACT_REGEX.test(segment)) {
          targetValue = segment.toUpperCase();
        } else {
          continue;
        }
      }

      if (!seen.has(targetValue)) {
        seen.add(targetValue);
        filtered.push(targetValue);
      }
    }

    trackingQueue = filtered;
    counterLabel.textContent = `0/${trackingQueue.length}`;
  }

  enableRtoAlarmChk.addEventListener('change', () => {
    enableRtoAlarm = enableRtoAlarmChk.checked;
    localStorage.setItem('barcode_enable_rto_alarm', enableRtoAlarm);
  });

  enableCpdAlarmChk.addEventListener('change', () => {
    enableCpdAlarm = enableCpdAlarmChk.checked;
    localStorage.setItem('barcode_enable_cpd_alarm', enableCpdAlarm);
  });

  testSoundBtn.addEventListener('click', () => {
    playRTOAlarmSound();
  });

  testCpdSoundBtn.addEventListener('click', () => {
    playCPDAlarmSound();
  });

  barcodeInput.addEventListener('input', processAndFilterQueue);
  
  isolateChk.addEventListener('change', () => {
    localStorage.setItem('barcode_isolate_tracking', isolateChk.checked);
    processAndFilterQueue();
  });

  enableExclusionChk.addEventListener('change', () => {
    localStorage.setItem('barcode_enable_exclusions', enableExclusionChk.checked);
    processAndFilterQueue();
  });

  excludeWordsInput.addEventListener('input', () => {
    localStorage.setItem('barcode_exclude_words', excludeWordsInput.value);
    processAndFilterQueue();
  });

  // Settings Modal Controls
  openExclusionsBtn.addEventListener('click', () => {
    exclusionsModal.classList.add('open');
    excludeWordsInput.focus();
  });

  closeModalBtn.addEventListener('click', () => {
    exclusionsModal.classList.remove('open');
  });

  saveModalBtn.addEventListener('click', () => {
    exclusionsModal.classList.remove('open');
  });

  // ---------------------------------------------------------------------------
  // 6. Hotkeys & UI Interaction
  // ---------------------------------------------------------------------------
  let recordingTarget = null;

  function bindHotkeyRecorder(inputEl, keyType) {
    inputEl.addEventListener('click', () => {
      recordingTarget = keyType;
      inputEl.value = "Press keys...";
      inputEl.style.borderColor = "#f59e0b";
    });

    inputEl.addEventListener('keydown', (e) => {
      if (recordingTarget !== keyType) return;
      e.preventDefault();
      e.stopPropagation();

      const keys = [];
      if (e.ctrlKey) keys.push('Ctrl');
      if (e.altKey) keys.push('Alt');
      if (e.shiftKey) keys.push('Shift');

      if (!['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) {
        keys.push(e.key.toUpperCase());
      }

      if (keys.length > 0 && !['Control', 'Alt', 'Shift'].includes(keys[keys.length - 1])) {
        const formattedHotkey = keys.join(' + ');
        if (keyType === 'toggle') {
          toggleHotkey = formattedHotkey;
          localStorage.setItem('barcode_toggle_hotkey', toggleHotkey);
        } else {
          startHotkey = formattedHotkey;
          localStorage.setItem('barcode_start_hotkey', startHotkey);
        }
        inputEl.value = formattedHotkey;
        inputEl.style.borderColor = "#cbd5e1";
        inputEl.blur();
        recordingTarget = null;
      }
    });

    inputEl.addEventListener('blur', () => {
      if (recordingTarget === keyType) {
        inputEl.value = keyType === 'toggle' ? toggleHotkey : startHotkey;
        inputEl.style.borderColor = "#cbd5e1";
        recordingTarget = null;
      }
    });
  }

  bindHotkeyRecorder(toggleHotkeyInput, 'toggle');
  bindHotkeyRecorder(startHotkeyInput, 'start');

  delayInput.addEventListener('change', () => {
    let val = parseInt(delayInput.value, 10);
    if (isNaN(val) || val < 0) val = 0;
    scanDelay = val;
    delayInput.value = scanDelay;
    localStorage.setItem('barcode_scan_delay', scanDelay);
  });

  window.addEventListener('keydown', (e) => {
    if (recordingTarget) return;

    function checkCombo(comboStr) {
      const parts = comboStr.split(' + ');
      const needCtrl = parts.includes('Ctrl');
      const needAlt = parts.includes('Alt');
      const needShift = parts.includes('Shift');
      const targetKey = parts[parts.length - 1];
      return e.ctrlKey === needCtrl && e.altKey === needAlt && e.shiftKey === needShift && e.key.toUpperCase() === targetKey;
    }

    if (checkCombo(toggleHotkey)) {
      e.preventDefault();
      panel.classList.toggle('panel-hidden');
    }

    if (checkCombo(startHotkey)) {
      e.preventDefault();
      if (!isRunning && !panel.classList.contains('panel-hidden')) {
        startBtn.click();
      }
    }
  });

  closeBtn.addEventListener('click', () => panel.classList.add('panel-hidden'));
  minimizeBtn.addEventListener('click', () => {
    panelBody.classList.toggle('minimized');
    minimizeBtn.textContent = panelBody.classList.contains('minimized') ? '+' : '—';
  });

  let isDragging = false, startX, startY;
  dragHandle.addEventListener('mousedown', (e) => {
    if (e.target === closeBtn || e.target === minimizeBtn) return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = panel.getBoundingClientRect();
    panel.style.bottom = 'auto';
    panel.style.right = 'auto';
    panel.style.left = `${rect.left}px`;
    panel.style.top = `${rect.top}px`;
  });

  window.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    panel.style.left = `${parseFloat(panel.style.left) + dx}px`;
    panel.style.top = `${parseFloat(panel.style.top) + dy}px`;
    startX = e.clientX;
    startY = e.clientY;
  });

  window.addEventListener('mouseup', () => isDragging = false);

  copyBtn.addEventListener('click', async () => {
    processAndFilterQueue();
    if (trackingQueue.length === 0) {
      alert("⚠️ No filtered tracking IDs to copy!");
      return;
    }
    try {
      await navigator.clipboard.writeText(trackingQueue.join('\n'));
      const originalText = copyBtn.textContent;
      copyBtn.textContent = '✅ Copied!';
      copyBtn.style.color = '#15803d';
      setTimeout(() => {
        copyBtn.textContent = originalText;
        copyBtn.style.color = '';
      }, 1500);
    } catch (err) {
      alert("⚠️ Click anywhere on the webpage once to grant clipboard permission.");
    }
  });

  pasteBtn.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      barcodeInput.value = text.trim();
      processAndFilterQueue();
    } catch (err) {
      alert("⚠️ Click anywhere on the webpage once to grant clipboard permission.");
    }
  });

  // ---------------------------------------------------------------------------
  // 7. Hardware Emulation Scanner Engine
  // ---------------------------------------------------------------------------
  async function simulateHardwareScan(element, text) {
    const inputProto = window.HTMLInputElement.prototype;
    const textareaProto = window.HTMLTextAreaElement.prototype;
    const nativeSetter = 
      Object.getOwnPropertyDescriptor(inputProto, 'value')?.set ||
      Object.getOwnPropertyDescriptor(textareaProto, 'value')?.set;

    if (nativeSetter) {
      nativeSetter.call(element, text);
    } else {
      element.value = text;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));

    ['keydown', 'keypress', 'keyup'].forEach(eventType => {
      element.dispatchEvent(new KeyboardEvent(eventType, {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true
      }));
    });
  }

  // Execution Controls
  resetKillBtn.addEventListener('click', () => {
    shouldStop = true;
    isRunning = false;
    isPaused = false;

    trackingQueue = [];
    currentIndex = 0;
    barcodeInput.value = '';

    startBtn.disabled = false;
    barcodeInput.disabled = false;
    pauseBtn.disabled = true;
    pauseBtn.textContent = '⏸ Pause';
    stopBtn.disabled = true;

    statusLabel.textContent = 'Status: Reset 🚨';
    counterLabel.textContent = '0/0';
    progressFill.style.width = '0%';
  });

  startBtn.addEventListener('click', async () => {
    processAndFilterQueue();
    if (trackingQueue.length === 0) {
      alert("⚠️ No valid tracking IDs match your filter settings!");
      return;
    }

    let activeEl = document.activeElement;
    if (activeEl === rootContainer) activeEl = null;
    if (!activeEl || (activeEl.tagName !== 'INPUT' && activeEl.tagName !== 'TEXTAREA')) {
      activeEl = document.querySelector('input[type="text"], input:not([type]), textarea');
    }

    if (!activeEl) {
      alert("⚠️ Click inside the Scan Shipment input field first!");
      return;
    }

    isRunning = true;
    isPaused = false;
    shouldStop = false;

    startBtn.disabled = true;
    barcodeInput.disabled = true;
    pauseBtn.disabled = false;
    stopBtn.disabled = false;

    for (currentIndex = 0; currentIndex < trackingQueue.length; currentIndex++) {
      if (shouldStop) break;

      while (isPaused) {
        statusLabel.textContent = "Status: Paused";
        await new Promise(res => setTimeout(res, 200));
        if (shouldStop) break;
      }
      if (shouldStop) break;

      const tid = trackingQueue[currentIndex];
      statusLabel.textContent = `Injecting: ${tid}`;
      counterLabel.textContent = `${currentIndex + 1}/${trackingQueue.length}`;
      progressFill.style.width = `${((currentIndex + 1) / trackingQueue.length) * 100}%`;

      activeEl.focus();
      await simulateHardwareScan(activeEl, tid);
      
      if (scanDelay > 0) {
        await new Promise(res => setTimeout(res, scanDelay));
      }
    }

    isRunning = false;
    startBtn.disabled = false;
    barcodeInput.disabled = false;
    pauseBtn.disabled = true;
    pauseBtn.textContent = '⏸ Pause';
    stopBtn.disabled = true;

    statusLabel.textContent = shouldStop ? "Status: Stopped" : "Status: Completed! ✅";
  });

  pauseBtn.addEventListener('click', () => {
    isPaused = !isPaused;
    pauseBtn.textContent = isPaused ? '▶ Resume' : '⏸ Pause';
    if (isPaused) statusLabel.textContent = 'Status: Paused';
  });

  stopBtn.addEventListener('click', () => {
    shouldStop = true;
    statusLabel.textContent = 'Status: Stopping...';
  });
})();