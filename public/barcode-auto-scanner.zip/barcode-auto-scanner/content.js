(function () {
  // ---------------------------------------------------------------------------
  // 1. React Extension Communication Bridge
  // ---------------------------------------------------------------------------
  // Ping response to verify extension installation
  window.addEventListener('CHECK_BARCODE_EXTENSION', () => {
    window.dispatchEvent(new CustomEvent('BARCODE_EXTENSION_INSTALLED', {
      detail: { version: '2.5', installed: true }
    }));
  });

  // Direct injection listener from BulkBarcodes.jsx
  window.addEventListener('LOAD_TRACKING_IDS_TO_EXTENSION', (event) => {
    if (event.detail && event.detail.trackingIds) {
      const barcodeInput = shadowRoot.getElementById('barcode-input');
      const counterLabel = shadowRoot.getElementById('counter-label');
      
      if (barcodeInput) {
        barcodeInput.value = event.detail.trackingIds;
        
        // Update local tracking queue
        trackingQueue = barcodeInput.value
          .split('\n')
          .map(id => id.trim())
          .filter(Boolean);
          
        if (counterLabel) {
          counterLabel.textContent = `0/${trackingQueue.length}`;
        }

        // Show panel when data is sent from website
        panel.classList.remove('panel-hidden');
        panelBody.classList.remove('minimized');
      }
    }
  });

  if (document.getElementById('barcode-injector-root')) return;

  // ---------------------------------------------------------------------------
  // 2. Persistent Settings State
  // ---------------------------------------------------------------------------
  let isRunning = false;
  let isPaused = false;
  let shouldStop = false;
  let trackingQueue = [];
  let currentIndex = 0;

  // Saved Preferences (or defaults)
  let toggleHotkey = localStorage.getItem('barcode_toggle_hotkey') || 'Alt + S';
  let startHotkey = localStorage.getItem('barcode_start_hotkey') || 'Alt + X';
  let scanDelay = parseInt(localStorage.getItem('barcode_scan_delay') || '800', 10);

  // Listen for extension action icon click
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {
      if (message.action === 'TOGGLE_PANEL') {
        panel.classList.toggle('panel-hidden');
      }
    });
  }

  // ---------------------------------------------------------------------------
  // 3. Shadow DOM Container Setup
  // ---------------------------------------------------------------------------
  const rootContainer = document.createElement('div');
  rootContainer.id = 'barcode-injector-root';
  document.body.appendChild(rootContainer);

  const shadowRoot = rootContainer.attachShadow({ mode: 'open' });

  // CSS Styles
  const style = document.createElement('style');
  style.textContent = `
    * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    #panel {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 340px;
      background: #ffffff;
      border: 1px solid #e0e0e0;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
      z-index: 999999;
      overflow: hidden;
      display: block;
    }
    #panel.panel-hidden { display: none !important; }
    .header {
      background: #1e293b;
      color: #ffffff;
      padding: 10px 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      cursor: move;
      user-select: none;
    }
    .header-title { font-weight: 600; font-size: 13px; display: flex; align-items: center; gap: 6px; }
    .header-btns { display: flex; gap: 6px; align-items: center; }
    .header-btns button {
      background: none; border: none; color: #94a3b8; font-size: 14px; cursor: pointer; padding: 0 2px;
    }
    .header-btns button:hover { color: #ffffff; }
    .body { padding: 12px; display: flex; flex-direction: column; gap: 10px; }
    .body.minimized { display: none; }
    
    label { font-size: 10px; font-weight: 700; color: #475569; text-transform: uppercase; }
    textarea {
      width: 100%; height: 75px; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px;
      font-size: 12px; font-family: monospace; resize: vertical; outline: none;
    }

    .btn-group { display: flex; gap: 6px; }
    button.btn {
      flex: 1; padding: 8px; border: none; border-radius: 6px; font-weight: 600; font-size: 12px;
      cursor: pointer; transition: all 0.15s ease; display: flex; align-items: center; justify-content: center; gap: 4px;
    }
    .btn-primary { background: #2563eb; color: white; }
    .btn-warning { background: #f59e0b; color: white; }
    .btn-danger { background: #ef4444; color: white; }
    .btn-reset { background: #dc2626; color: white; width: 100%; font-weight: 700; }
    .btn-secondary { background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; }
    button:disabled { opacity: 0.5; cursor: not-allowed; }

    .progress-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px; }
    .progress-bar-bg { background: #e2e8f0; height: 6px; border-radius: 3px; overflow: hidden; margin-top: 6px; }
    .progress-bar-fill { background: #2563eb; height: 100%; width: 0%; transition: width 0.2s ease; }
    .status-text { font-size: 11px; color: #64748b; display: flex; justify-content: space-between; }

    .settings-grid {
      background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px;
      display: flex; flex-direction: column; gap: 6px;
    }
    .setting-row { display: flex; justify-content: space-between; align-items: center; }
    .setting-input {
      background: #ffffff; border: 1px solid #cbd5e1; border-radius: 4px; padding: 3px 6px;
      font-size: 11px; font-weight: bold; color: #2563eb; width: 100px; text-align: center; cursor: pointer;
    }
    .setting-input:focus { border-color: #2563eb; background: #eff6ff; }
  `;

  // UI Markup (Starts hidden with 'panel-hidden' class)
  const panel = document.createElement('div');
  panel.id = 'panel';
  panel.className = 'panel-hidden';
  panel.innerHTML = `
    <div class="header" id="drag-handle">
      <span class="header-title">⚡ Barcode Injector Pro</span>
      <div class="header-btns">
        <button id="minimize-btn" title="Minimize">—</button>
        <button id="close-btn" title="Close Panel">✕</button>
      </div>
    </div>
    <div class="body" id="panel-body">
      <div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
          <label>Tracking IDs (One Per Line)</label>
          <button id="paste-btn" class="btn btn-secondary" style="padding:2px 6px; font-size:10px;">📋 Paste Clipboard</button>
        </div>
        <textarea id="barcode-input" placeholder="Paste or type tracking IDs here..."></textarea>
      </div>

      <div class="settings-grid">
        <div class="setting-row">
          <label>Hide/Show Shortcut:</label>
          <input type="text" id="toggle-hotkey-input" class="setting-input" value="${toggleHotkey}" readonly title="Click to record toggle key" />
        </div>
        <div class="setting-row">
          <label>Start Scan Shortcut:</label>
          <input type="text" id="start-hotkey-input" class="setting-input" value="${startHotkey}" readonly title="Click to record start key" />
        </div>
        <div class="setting-row">
          <label>Interval Delay (ms):</label>
          <input type="number" id="delay-input" class="setting-input" style="cursor:text;" value="${scanDelay}" step="100" min="100" />
        </div>
      </div>

      <div class="btn-group">
        <button id="start-btn" class="btn btn-primary">▶ Start</button>
        <button id="pause-btn" class="btn btn-warning" disabled>⏸ Pause</button>
        <button id="stop-btn" class="btn btn-danger" disabled>⏹ Stop</button>
      </div>

      <button id="reset-kill-btn" class="btn btn-reset">🚨 Emergency Kill & Reset</button>

      <div class="progress-box">
        <div class="status-text">
          <span id="status-label">Status: Idle</span>
          <span id="counter-label">0/0</span>
        </div>
        <div class="progress-bar-bg">
          <div id="progress-fill" class="progress-bar-fill"></div>
        </div>
      </div>
    </div>
  `;

  shadowRoot.appendChild(style);
  shadowRoot.appendChild(panel);

  // References
  const barcodeInput = shadowRoot.getElementById('barcode-input');
  const startBtn = shadowRoot.getElementById('start-btn');
  const pauseBtn = shadowRoot.getElementById('pause-btn');
  const stopBtn = shadowRoot.getElementById('stop-btn');
  const resetKillBtn = shadowRoot.getElementById('reset-kill-btn');
  const pasteBtn = shadowRoot.getElementById('paste-btn');
  const minimizeBtn = shadowRoot.getElementById('minimize-btn');
  const closeBtn = shadowRoot.getElementById('close-btn');
  const panelBody = shadowRoot.getElementById('panel-body');
  const statusLabel = shadowRoot.getElementById('status-label');
  const counterLabel = shadowRoot.getElementById('counter-label');
  const progressFill = shadowRoot.getElementById('progress-fill');
  const dragHandle = shadowRoot.getElementById('drag-handle');
  
  const toggleHotkeyInput = shadowRoot.getElementById('toggle-hotkey-input');
  const startHotkeyInput = shadowRoot.getElementById('start-hotkey-input');
  const delayInput = shadowRoot.getElementById('delay-input');

  // ---------------------------------------------------------------------------
  // 4. Dynamic Settings & Hotkey Handlers
  // ---------------------------------------------------------------------------
  let recordingTarget = null;

  function bindHotkeyRecorder(inputEl, keyType) {
    inputEl.addEventListener('click', () => {
      recordingTarget = keyType;
      inputEl.value = "Press keys...";
      inputEl.style.borderColor = "#f59e0b";
    });

    inputEl.addEventListener('keydown', (e) => {
      if (recordingTarget !== keyType) return;
      e.preventDefault();
      e.stopPropagation();

      const keys = [];
      if (e.ctrlKey) keys.push('Ctrl');
      if (e.altKey) keys.push('Alt');
      if (e.shiftKey) keys.push('Shift');

      if (!['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) {
        keys.push(e.key.toUpperCase());
      }

      if (keys.length > 0 && !['Control', 'Alt', 'Shift'].includes(keys[keys.length - 1])) {
        const formattedHotkey = keys.join(' + ');
        if (keyType === 'toggle') {
          toggleHotkey = formattedHotkey;
          localStorage.setItem('barcode_toggle_hotkey', toggleHotkey);
        } else {
          startHotkey = formattedHotkey;
          localStorage.setItem('barcode_start_hotkey', startHotkey);
        }
        inputEl.value = formattedHotkey;
        inputEl.style.borderColor = "#cbd5e1";
        inputEl.blur();
        recordingTarget = null;
      }
    });

    inputEl.addEventListener('blur', () => {
      if (recordingTarget === keyType) {
        inputEl.value = keyType === 'toggle' ? toggleHotkey : startHotkey;
        inputEl.style.borderColor = "#cbd5e1";
        recordingTarget = null;
      }
    });
  }

  bindHotkeyRecorder(toggleHotkeyInput, 'toggle');
  bindHotkeyRecorder(startHotkeyInput, 'start');

  delayInput.addEventListener('change', () => {
    let val = parseInt(delayInput.value, 10);
    if (isNaN(val) || val < 50) val = 100;
    scanDelay = val;
    delayInput.value = scanDelay;
    localStorage.setItem('barcode_scan_delay', scanDelay);
  });

  // Global Keydown Listener
  window.addEventListener('keydown', (e) => {
    if (recordingTarget) return;

    function checkCombo(comboStr) {
      const parts = comboStr.split(' + ');
      const needCtrl = parts.includes('Ctrl');
      const needAlt = parts.includes('Alt');
      const needShift = parts.includes('Shift');
      const targetKey = parts[parts.length - 1];
      return e.ctrlKey === needCtrl && e.altKey === needAlt && e.shiftKey === needShift && e.key.toUpperCase() === targetKey;
    }

    if (checkCombo(toggleHotkey)) {
      e.preventDefault();
      panel.classList.toggle('panel-hidden');
    }

    if (checkCombo(startHotkey)) {
      e.preventDefault();
      if (!isRunning && !panel.classList.contains('panel-hidden')) {
        startBtn.click();
      }
    }
  });

  // ---------------------------------------------------------------------------
  // 5. UI Controls
  // ---------------------------------------------------------------------------
  closeBtn.addEventListener('click', () => {
    panel.classList.add('panel-hidden');
  });

  minimizeBtn.addEventListener('click', () => {
    panelBody.classList.toggle('minimized');
    minimizeBtn.textContent = panelBody.classList.contains('minimized') ? '+' : '—';
  });

  let isDragging = false, startX, startY;
  dragHandle.addEventListener('mousedown', (e) => {
    if (e.target === closeBtn || e.target === minimizeBtn) return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = panel.getBoundingClientRect();
    panel.style.bottom = 'auto';
    panel.style.right = 'auto';
    panel.style.left = `${rect.left}px`;
    panel.style.top = `${rect.top}px`;
  });

  window.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    panel.style.left = `${parseFloat(panel.style.left) + dx}px`;
    panel.style.top = `${parseFloat(panel.style.top) + dy}px`;
    startX = e.clientX;
    startY = e.clientY;
  });

  window.addEventListener('mouseup', () => isDragging = false);

  // Safe Clipboard Reading
  pasteBtn.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      barcodeInput.value = text.trim();
      updateQueueFromInput();
    } catch (err) {
      alert("⚠️ Click anywhere on the webpage once to grant clipboard permission.");
    }
  });

  function updateQueueFromInput() {
    trackingQueue = barcodeInput.value
      .split('\n')
      .map(id => id.trim())
      .filter(Boolean);
    counterLabel.textContent = `0/${trackingQueue.length}`;
  }

  barcodeInput.addEventListener('input', updateQueueFromInput);

  // ---------------------------------------------------------------------------
  // 6. Emergency Reset & Injection Engine (Buffer Flush Protected)
  // ---------------------------------------------------------------------------
  resetKillBtn.addEventListener('click', () => {
    shouldStop = true;
    isRunning = false;
    isPaused = false;

    trackingQueue = [];
    currentIndex = 0;
    barcodeInput.value = '';

    startBtn.disabled = false;
    barcodeInput.disabled = false;
    pauseBtn.disabled = true;
    pauseBtn.textContent = '⏸ Pause';
    stopBtn.disabled = true;

    statusLabel.textContent = 'Status: Process Reset 🚨';
    counterLabel.textContent = '0/0';
    progressFill.style.width = '0%';
  });

  startBtn.addEventListener('click', async () => {
    updateQueueFromInput();
    if (trackingQueue.length === 0) {
      alert("⚠️ Please enter or paste at least one tracking ID!");
      return;
    }

    let activeEl = document.activeElement;
    if (activeEl === rootContainer) activeEl = null;
    if (!activeEl || (activeEl.tagName !== 'INPUT' && activeEl.tagName !== 'TEXTAREA')) {
      activeEl = document.querySelector('input[type="text"], input:not([type]), textarea');
    }

    if (!activeEl) {
      alert("⚠️ Click inside your dashboard's search/input box first!");
      return;
    }

    isRunning = true;
    isPaused = false;
    shouldStop = false;
    currentIndex = 0;

    startBtn.disabled = true;
    barcodeInput.disabled = true;
    pauseBtn.disabled = false;
    stopBtn.disabled = false;

    const inputProto = window.HTMLInputElement.prototype;
    const textareaProto = window.HTMLTextAreaElement.prototype;
    const nativeSetter = 
      Object.getOwnPropertyDescriptor(inputProto, 'value')?.set ||
      Object.getOwnPropertyDescriptor(textareaProto, 'value')?.set;

    for (currentIndex = 0; currentIndex < trackingQueue.length; currentIndex++) {
      if (shouldStop) break;

      while (isPaused) {
        statusLabel.textContent = "Status: Paused";
        await new Promise(res => setTimeout(res, 200));
        if (shouldStop) break;
      }
      if (shouldStop) break;

      const tid = trackingQueue[currentIndex];
      statusLabel.textContent = `Injecting: ${tid}`;
      counterLabel.textContent = `${currentIndex + 1}/${trackingQueue.length}`;
      progressFill.style.width = `${((currentIndex + 1) / trackingQueue.length) * 100}%`;

      activeEl.focus();

      // -----------------------------------------------------------------------
      // STEP A: CLEAR DASHBOARD INTERNAL KEY/SCAN BUFFER
      // -----------------------------------------------------------------------
      // Send Escape key signal to clear any dirty buffer in window/document handlers
      activeEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));

      // Wipe value completely
      if (nativeSetter) {
        nativeSetter.call(activeEl, '');
      } else {
        activeEl.value = '';
      }
      activeEl.dispatchEvent(new Event('input', { bubbles: true }));
      activeEl.dispatchEvent(new Event('change', { bubbles: true }));

      // Short delay for dashboard internal memory buffer reset
      await new Promise(res => setTimeout(res, 50));

      // -----------------------------------------------------------------------
      // STEP B: INJECT NEW TRACKING ID
      // -----------------------------------------------------------------------
      if (nativeSetter) {
        nativeSetter.call(activeEl, tid);
      } else {
        activeEl.value = tid;
      }

      activeEl.dispatchEvent(new Event('input', { bubbles: true }));
      activeEl.dispatchEvent(new Event('change', { bubbles: true }));

      // -----------------------------------------------------------------------
      // STEP C: DISPATCH ENTER KEY SIGNALS
      // -----------------------------------------------------------------------
      ['keydown', 'keypress', 'keyup'].forEach(type => {
        activeEl.dispatchEvent(new KeyboardEvent(type, {
          key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true
        }));
      });

      await new Promise(res => setTimeout(res, scanDelay));
    }

    isRunning = false;
    startBtn.disabled = false;
    barcodeInput.disabled = false;
    pauseBtn.disabled = true;
    pauseBtn.textContent = '⏸ Pause';
    stopBtn.disabled = true;

    if (shouldStop) {
      statusLabel.textContent = "Status: Stopped";
    } else {
      statusLabel.textContent = "Status: Completed! ✅";
    }
  });

  pauseBtn.addEventListener('click', () => {
    isPaused = !isPaused;
    if (isPaused) {
      pauseBtn.textContent = '▶ Resume';
      statusLabel.textContent = 'Status: Paused';
    } else {
      pauseBtn.textContent = '⏸ Pause';
    }
  });

  stopBtn.addEventListener('click', () => {
    shouldStop = true;
    statusLabel.textContent = 'Status: Stopping...';
  });
})();